console.log("Initializing Result Script");

let ace = window.wrappedJSObject.ace;
XPCNativeWrapper(window.wrappedJSObject.ace);

let QNA = {};


//Listening and Responding to Popup 
browser.runtime.onMessage.addListener((msg,sender,sendResponse) =>{
    //console.log("Received a Message",msg,sender);
    if(msg.request == "SendMeNuds" && msg.from == "Popup"){
        console.log("Responding to Message");
        let commands = [
            {
                command : "F1",
                operation : "Capture & Download"
            }
        ]
        sendResponse(commands);
    }
    return false;
})
    
let _FontEmbedCSS_;
fetch(browser.runtime.getURL("lib/CCSS.txt"))
.then(response => response.text())
.then(css => {_FontEmbedCSS_ = css; console.log("CSS Object Ready for Action")});

document.addEventListener("keyup",e => { 
    if(e.key == "F1") {
        extract();
        console.log("Called Extraction");
    }

});
        
async function extract(){
    QNA["test"] = document.querySelectorAll(".ra-title-value")[2].innerText.replace(" ","_");
    QNA["qaPairs"] = {};
    //QNA["Language"] = ace.edit(document.querySelector(".editor-answer").id).getSession().getMode().$id.split("/")[2].split("_")[0];
    let qapairs = document.getElementsByClassName("ra-section-each-question");
    //document.querySelectorAll("link[rel='stylesheet")[0].href = browser.runtime.getURL("Test/styles.6f5a656b104335294a50.css");
    /*
    let styleLinks = document.querySelectorAll("link[rel='stylesheet']");
    for(let i=1;i<styleLinks.length;i++)
        styleLinks[i].remove();
    */
    //const _FontEmbedCSS_ = await htmlToImage.getFontEmbedCSS(qapairs[0]);
    //download(_FontEmbedCSS_,"ScriptCSS.txt","text/plain");
    //console.log("FontCSSMaybeExtracted");
    for(let qa of qapairs){
        try{
            let  ques_ans= {}
            ques_ans["id"] = extractQID(qa);
            ques_ans["question"] = await constructQuestion(qa,_FontEmbedCSS_);
            [ques_ans["lang"],ques_ans["header"],ques_ans["answer"],ques_ans["footer"]] = getAnswer(qa);
            console.log(ques_ans["id"] ,"Finished Processing");
            QNA.qaPairs[ques_ans.id] = ques_ans;
        }catch(e){
            console.log(e)
        }
    }
    console.log("Sending Message");
    browser.runtime.sendMessage({"request":"download","attachedObject":QNA});
    console.log(Object.keys(QNA.qaPairs));
}

function extractQID(question){
    let questionNo = question.querySelector(".ra-section-question-no").innerText;
    questionNo = "Q"+questionNo.split(" ")[2];
    return questionNo;
}

function styleSheetFuckery(){
    let styleLinks = document.querySelectorAll("link[rel='stylesheet']");
    for(let i=0;i<styleLinks.length;i++){
      fetch(styleLinks[i].href)
      .then(response => response.blob())
      .then(blob => {
           styleLinks[i].href=URL.createObjectURL(blob)
      })
    }
}

async function cleanUP(element){

    let images = element.querySelectorAll('img');
    for(let i of images){
        //i.crossOrigin = "anonymous"
        
        await content.fetch(i.src)
        .then(response => response.blob())
        .then(blob => i.src = URL.createObjectURL(blob));
    }
}

async function constructQuestion(question,FontEmbedCSS){
    let renderedImage;
    console.log("Cleaning");
    await cleanUP(question);
    console.log("Cleaning Finished");

    /*
    await html2canvas(question,{
        allowTaint:true,
        //foreignObjectRendering: true,
        ignoreElements: element => element.className === "ra-section-answer-card",
        useCORS:true,
        width:question.scrollWidth,
        height:question.scrollHeight-question.lastChild.scrollHeight,
    }).then(canvas => {
        renderedImage = canvas.toDataURL();
        let questionHead = question.querySelector(".ra-section-question-header");
        let input = document.createElement("input");
        input.type = "button";
        input.onclick = () => window.open(renderedImage,"_blank");
        input.value = "Preview";
        input.textContent = "Preview Image"
        questionHead.appendChild(input);
    })
    */
    

    await htmlToImage.toBlob(question,
        {
            backgroundColor: '#ffffff',
            quality : 1, //100%
            filter: element => element.className !== "ra-section-answer-card", //Excludes answer container
            width: question.scrollWidth,
            height : question.scrollHeight-question.lastChild.scrollHeight,
            fontEmbedCSS : FontEmbedCSS, //A constant CSS to prevent multiple downloads of CSS sheets
        }
    ).then(blob => {
        renderedImage = blob;
        let questionHead = question.querySelector(".ra-section-question-header");
        //questionHead.appendChild(blob);
        //browser.downloads.download({url:blob,saveAs:true});
        let input = document.createElement("input");
        input.type = "button";
        input.onclick = () => window.open(URL.createObjectURL(blob),"_blank");
        input.value = "Preview";
        input.textContent = "Preview Image"
        questionHead.appendChild(input);
    })

   return renderedImage;
}

function getAnswer(question){
    let answer = question.querySelector(".programming-container");

    let headEditorID = answer.querySelector(".header-content .editor-question").id;
    let editorID = answer.querySelector(".editor-answer").id;
    let footEditorID = answer.querySelector(".footer-content .editor-question").id;

    let headEditorText = (headEditorID)?ace.edit(headEditorID).getValue():"";
    let editorText = ace.edit(editorID).getValue();
    let footEditorText = (footEditorID)?ace.edit(footEditorID).getValue():"";

    let language = ace.edit(editorID).session.$modeId.split("/")[2].split("_");
    language = (language.length > 1)?language[language.length-1]:language[0];

    return [language,headEditorText,editorText,footEditorText];
}


