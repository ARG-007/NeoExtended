//import saveAs  from "./lib/FileSaver.js";

browser.runtime.onMessage.addListener(processMessage);

function processMessage(message){
    console.log("Got Something!:",message);
    if(message.request === "download") download(message.attachedObject);
}

function download(qna){
    console.log("Downloading.....");

    const testTile = qna.test;
    const mdImageTag = (id,image) => `# ${id}\n\n# ![${id}](${image})\n\n`;
    const code = (lang,code) => `\`\`\`${lang}\n${code}\n\`\`\``
    const seperator = "\n\n"+"-".repeat(30)+"\n\n";

    let markDown = "";
    let imagesToDownload = []
    for(let qa of Object.values(qna.qaPairs)){
        let codeAnswer = code(qa.lang,qa.answer);

        if(qa.header||qa.footer){
            codeAnswer = "\n> **Written Code:**\n"+codeAnswer;
            if(qa.header) codeAnswer = "\n> **Header Snippet:**\n"+code(qa.lang,qa.header)+codeAnswer;
            if(qa.footer) codeAnswer += "\n> **Footer Snippet:**\n"+code(qa.lang,qa.footer);
        }

        let imageName = `${testTile}//${qa.id}.png`;
        let qaText = mdImageTag(qa.id,imageName) + codeAnswer + seperator;
        let qaImage = new File([qa.question],imageName,{type:"image/png"});

        imagesToDownload.push(qaImage);
        markDown += qaText;
    }

    let markDownFile = new File([markDown],`${testTile}.md`,{type:"text/plain;charset=utf-8"});

    browser.downloads.download({
        url:URL.createObjectURL(markDownFile),
        filename: "course//"+markDownFile.name
    });
    
    imagesToDownload.forEach(image => {
        let imageUrl = URL.createObjectURL(image);
        //debugger;
        let downloading = browser.downloads.download({
            url:imageUrl,
            filename:"course//"+image.name
        });
    })
}
