document.addEventListener("keyup",eventHandler);
console.log("Initializing Test Script");

let ace = window.wrappedJSObject.ace;
XPCNativeWrapper(window.wrappedJSObject.ace);

let QNA = {};
QNA["qaPairs"] = {};


let _FontEmbedCSS_;
fetch(browser.runtime.getURL("lib/CCSS.txt"))
.then(response => response.text())
.then(css => {_FontEmbedCSS_ = css; console.log("CSS Object Ready for Action")});

browser.runtime.onMessage.addListener((msg,sender,sendResponse) =>{
    //console.log("Received a Message",msg);
    if(msg.request == "SendMeNuds" && msg.from == "Popup"){
        console.log("Responding To Message");
        let commands = [
            {
                command : "Ctrl+Shift+Z",
                operation : "Paste Into Editor"
            },
            {
                command : "F2",
                operation : "Copy From Editor"
            },
            {
                command : "F1",
                operation : "Screenshot Question & copy Answer"
            },
            {
                command : "F4",
                operation : "Download Captured Question and Answer"
            },
        ]
        sendResponse(commands);
    }
})

function eventHandler(e){
    //Paste Action
    
    if(e.ctrlKey && e.shiftKey && e.key=="Z"){
        let editorID = e.originalTarget.offsetParent.id;
        //injectScript("PASTE",editorID);
        
        console.log("Paste Action Started");
        
        let editor = ace.edit(editorID);

        navigator.clipboard.readText().then((text) => {
            editor.insert(text);
        });

        console.log("Paste Action Finished");
        
    }
    
    //Copy Action
    if(e.key=="F2"){
        let editorID = e.originalTarget.offsetParent.id;
        
        console.log("Copy Action Started");
        
        let editor = ace.edit(editorID);
        let text = editor.getSelectedText();
        text = !!(text)?text:editor.getValue();

        navigator.clipboard.writeText(text);
        console.log("Copy Action Finished");
    }
    
    if(e.key=="F1") captureQA();
    if(e.key=="F4") browser.runtime.sendMessage({request:"download",attachedObject:QNA});
}

async function captureQA(){
    QNA["test"] = document.querySelector(".header-title").innerText;
    let qna = {};

    console.log("Started Question Imaging");
    let node = document.querySelector(".question");
    let qid = node.querySelector(".question-no").innerText;

    qna["id"] = qid.replace(" - ","");

    let headEditorID = document.querySelector(".header-content .editor-question").id;
    let editorID = document.querySelector(".editor-answer").id;
    let footEditorID = document.querySelector(".footer-content .editor-question").id;

    qna["header"] = (headEditorID)? ace.edit(headEditorID).getValue() : "";
    qna["answer"] = ace.edit(editorID).getValue();
    qna["footer"] = (footEditorID)? ace.edit(footEditorID).getValue() : "";
    
    qna["lang"] = ace.edit(editorID).session.$modeId.split("/")[2].split("_");
    qna["lang"] = (qna["lang"].length>1)?qna["lang"][qna["lang"].length-1]:qna["lang"][0];

    console.log("Cleaning Question Images");
    let images = node.querySelectorAll('img');
    for(let i of images){
        await content.fetch(i.src)
        .then(response => response.blob())
        .then(blob => i.src = URL.createObjectURL(blob));
    }
    console.log("Purification Completed");

    await htmlToImage.toBlob(node,
        {
            backgroundColor: '#ffffff',
            width : node.scrollWidth,
            height: node.scrollHeight,
            fontEmbedCSS : _FontEmbedCSS_
        }
    )
    .then(blob=>{
        qna["question"] = blob;
        console.log("Finished Imaging");
    })
    .catch(error => console.log(error));

    QNA.qaPairs[qid] = qna;
}



/*
document.addEventListener("Penetrated",(e)=> {
    //console.log(e.detail.ace);
    let ace = e.detail.ace;
    ace.edit(task.detail.auxAction).insert("Meh");
    //wind = e.detail.window;
    //executeTask(e);
})

/*
function executeTask(task){
    let ace = task.detail.ace;
    switch(task.detail.action){
        case "PASTE": ace.edit(task.detail.auxAction).insert("Meh")/*pasteAction(wind,task.detail.auxAction);break;
        case "COPY": /*copyAction(wind,task.detail.auxAction);break;
    }
}
*/

/*
function pasteAction(ace,editorID){
    //let ace = window.ace;
    console.log(ace);
    let editor = ace.edit(editorID);
    console.log(ace,editor);
    navigator.clipboard.readText().then((text) => editor.insert(text));
}

function copyAction(ace,editorID){
    //let ace = window.ace;
    let editor = ace.edit(editorID);
    console.log(ace,editor);
    navigator.clipboard.writeText(editor.getValue());
}
*/
/*
function injectScript(action,auxMes){
    let script = document.createElement("script");
    script.textContent = "("+ function(message,auxAct){
        document.dispatchEvent(new CustomEvent("Penetrated",{
            detail: {
                action:message,
                auxAction:auxAct,
                ace : ace
            }
        }))
    }+")("+JSON.stringify(action)+","+JSON.stringify(auxMes)+");";
    (document.head||document.documentElement).append(script);
    script.onload = function() {
        script.remove();
    };
}
*/