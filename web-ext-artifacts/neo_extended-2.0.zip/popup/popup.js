console.log("Sending Message")

const appendInfo = (commands) => {
    console.log("Received Message",commands);
    for(let command of commands) {
        let commandDiv = document.createElement("p");
        commandDiv.textContent = command.command +" : "+ command.operation
        document.querySelector("#ListenerArea").appendChild(commandDiv);
    }
}

browser.runtime.onMessage.addListener(appendInfo)

browser.tabs.query({
    active:true,
    currentWindow:true
},
tabs => browser.tabs.sendMessage(tabs[0].id,{from:"Popup",request:"SendMeNuds"},appendInfo))

