function paste(message){
    if(message.command == "paste"){
        window.ace.edit(message.editor).then((editor) => editor.insert("clipboard.read()"));
    }
}

browser.runtime.onMessage.addListener(paste);
