//import html2canvas from 'lib/html2canvas';

document.addEventListener("keyup",eventHandler);

function eventHandler(e){
    //Paste Action
    
    if(e.ctrlKey && e.shiftKey && e.key=="Z"){
        let editorID = e.originalTarget.offsetParent.id;
        //injectScript("PASTE",editorID);
        
        console.log("Paste Action Started");
        var ace = e.view.wrappedJSObject.ace;
        XPCNativeWrapper(e.view.wrappedJSObject.ace);
        
        var editor = ace.edit(editorID);
        navigator.clipboard.readText().then((text) => {
            editor.insert(text);
        });
        console.log("Paste Action Finished");
        
    }
    
    //Copy Action
    if(e.ctrlKey && e.shiftKey && e.key=="S"){
        let editorID = e.originalTarget.offsetParent.id;
        //injectScript("COPY",editorID);
        
        console.log("Copy Action Started");
        var ace = e.view.wrappedJSObject.ace;
        XPCNativeWrapper(e.view.wrappedJSObject.ace);
        
        var editor = ace.edit(editorID);
        //console.log(editor.getValue());
        let text = editor.getSelectedText();
        text = !!(text)?text:editor.getValue();
        navigator.clipboard.writeText(text);
        console.log("Copy Action Finished");
    }
}

/*
document.addEventListener("Penetrated",(e)=> {
    //console.log(e.detail.ace);
    let ace = e.detail.ace;
    ace.edit(task.detail.auxAction).insert("Meh");
    //wind = e.detail.window;
    //executeTask(e);
})

/*
function executeTask(task){
    let ace = task.detail.ace;
    switch(task.detail.action){
        case "PASTE": ace.edit(task.detail.auxAction).insert("Meh")/*pasteAction(wind,task.detail.auxAction);break;
        case "COPY": /*copyAction(wind,task.detail.auxAction);break;
    }
}
*/

/*
function pasteAction(ace,editorID){
    //let ace = window.ace;
    console.log(ace);
    let editor = ace.edit(editorID);
    console.log(ace,editor);
    navigator.clipboard.readText().then((text) => editor.insert(text));
}

function copyAction(ace,editorID){
    //let ace = window.ace;
    let editor = ace.edit(editorID);
    console.log(ace,editor);
    navigator.clipboard.writeText(editor.getValue());
}
*/
/*
function injectScript(action,auxMes){
    let script = document.createElement("script");
    script.textContent = "("+ function(message,auxAct){
        document.dispatchEvent(new CustomEvent("Penetrated",{
            detail: {
                action:message,
                auxAction:auxAct,
                ace : ace
            }
        }))
    }+")("+JSON.stringify(action)+","+JSON.stringify(auxMes)+");";
    (document.head||document.documentElement).append(script);
    script.onload = function() {
        script.remove();
    };
}
*/